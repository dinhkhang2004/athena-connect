import { useState } from "react";
import { ArrowLeft, ChevronRight, Flag, Calendar, Upload, Plus, X } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { cn } from "@/lib/utils";

const priorities = [
  { id: "normal", label: "Bình thường", color: "bg-[#E3F2FD] text-[#0052CC]", icon: Flag },
  { id: "urgent", label: "Gấp", color: "bg-[#FF9800] text-white", icon: Flag },
  { id: "high", label: "Cao", color: "bg-[#F44336] text-white", icon: Flag },
  { id: "low", label: "Thấp", color: "bg-[#E8F5E8] text-success-foreground", icon: Flag },
];

const CreateTicket = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const conversationData = location.state?.conversation;

  const [priority, setPriority] = useState("normal");
  const [ticketName, setTicketName] = useState("");
  const [description, setDescription] = useState("");
  const [infoOpen, setInfoOpen] = useState(true);
  const [attachmentOpen, setAttachmentOpen] = useState(true);
  const [staffOpen, setStaffOpen] = useState(true);
  const [fileOpen, setFileOpen] = useState(false);
  const [timeOpen, setTimeOpen] = useState(false);
  const [tasks, setTasks] = useState<string[]>([]);
  const [newTask, setNewTask] = useState("");

  const handleAddTask = () => {
    if (newTask.trim()) {
      setTasks([...tasks, newTask]);
      setNewTask("");
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA]">
      {/* Header */}
      <div className="bg-background border-b border-border p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(-1)}
              className="h-9 w-9"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-semibold text-foreground">Tạo phiếu ghi mới</h1>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-6">
        <div className="grid grid-cols-12 gap-6">
          {/* Left Column - 55% */}
          <div className="col-span-12 lg:col-span-7 space-y-4">
            {/* Thông tin phiếu ghi */}
            <Collapsible open={infoOpen} onOpenChange={setInfoOpen} className="bg-background rounded-lg border border-border">
              <CollapsibleTrigger className="w-full p-4 flex items-center justify-between hover:bg-background-secondary transition-colors">
                <h3 className="font-semibold text-foreground">Thông tin phiếu ghi</h3>
                <ChevronRight className={cn("h-4 w-4 text-text-secondary transition-transform", infoOpen && "rotate-90")} />
              </CollapsibleTrigger>
              <CollapsibleContent>
                <div className="p-4 pt-0 space-y-4">
                  {/* Priority Pills */}
                  <div>
                    <Label className="text-sm text-text-secondary mb-2 block">Độ ưu tiên</Label>
                    <div className="flex gap-2 flex-wrap">
                      {priorities.map((p) => (
                        <button
                          key={p.id}
                          onClick={() => setPriority(p.id)}
                          className={cn(
                            "px-4 py-2 rounded-full text-sm font-medium transition-all flex items-center gap-2",
                            priority === p.id ? p.color : "bg-background-secondary text-text-secondary"
                          )}
                        >
                          <p.icon className="h-3 w-3" />
                          {p.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Tên phiếu ghi */}
                  <div>
                    <Label className="text-sm text-foreground mb-2 block">
                      Tên phiếu ghi <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      value={ticketName}
                      onChange={(e) => setTicketName(e.target.value)}
                      placeholder="Tối đa 256 ký tự"
                      className="border-border"
                      maxLength={256}
                    />
                  </div>

                  {/* Chủ đề */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm text-text-secondary mb-2 block">Chủ đề</Label>
                      <Select defaultValue="default">
                        <SelectTrigger className="border-border">
                          <SelectValue placeholder="Chọn chủ đề" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="default">Mặc định</SelectItem>
                          <SelectItem value="technical">Kỹ thuật</SelectItem>
                          <SelectItem value="billing">Thanh toán</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Phân loại */}
                    <div>
                      <Label className="text-sm text-text-secondary mb-2 block">Phân loại</Label>
                      <Select>
                        <SelectTrigger className="border-border">
                          <SelectValue placeholder="Chọn tùy chọn" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="enquiry">Enquiry</SelectItem>
                          <SelectItem value="complaint">Complaint</SelectItem>
                          <SelectItem value="request">Request</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Mô tả - Rich Text Editor */}
                  <div>
                    <Label className="text-sm text-text-secondary mb-2 block">Mô tả</Label>
                    <div className="border border-border rounded-lg overflow-hidden">
                      <div className="border-b border-border p-2 flex items-center gap-1 bg-background-secondary">
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <span className="text-xs">←</span>
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <span className="text-xs">→</span>
                        </Button>
                        <div className="w-px h-4 bg-border mx-1" />
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <span className="text-xs font-bold">B</span>
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <span className="text-xs italic">I</span>
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <span className="text-xs">A</span>
                        </Button>
                        <div className="w-px h-4 bg-border mx-1" />
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <span className="text-xs">•</span>
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <span className="text-xs">1.</span>
                        </Button>
                        <div className="ml-auto text-xs text-text-secondary">Xem đầy đủ</div>
                      </div>
                      <Textarea
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        placeholder="Nhập giá trị"
                        className="border-0 min-h-[100px] resize-none focus-visible:ring-0"
                      />
                    </div>
                  </div>

                  {/* Mặc định */}
                  <div>
                    <Label className="text-sm text-text-secondary mb-2 block">Mặc định</Label>
                    <Input placeholder="Tối đa 256 ký tự" className="border-border" maxLength={256} />
                  </div>

                  {/* Tag */}
                  <div>
                    <Label className="text-sm text-text-secondary mb-2 block">Tag</Label>
                    <Input placeholder="Chưa có dữ liệu" className="border-border bg-background-secondary" disabled />
                  </div>
                </div>
              </CollapsibleContent>
            </Collapsible>
          </div>

          {/* Right Column - 45% */}
          <div className="col-span-12 lg:col-span-5 space-y-4">
            {/* Đối tượng đính kèm */}
            <Collapsible open={attachmentOpen} onOpenChange={setAttachmentOpen} className="bg-background rounded-lg border border-border">
              <CollapsibleTrigger className="w-full p-4 flex items-center justify-between hover:bg-background-secondary transition-colors">
                <h3 className="font-semibold text-foreground">Đối tượng đính kèm</h3>
                <ChevronRight className={cn("h-4 w-4 text-text-secondary transition-transform", attachmentOpen && "rotate-90")} />
              </CollapsibleTrigger>
              <CollapsibleContent>
                <div className="p-4 pt-0 space-y-3">
                  {/* Conversation Card */}
                  <div className="border border-border rounded-lg p-3 bg-background-secondary">
                    <div className="flex items-start gap-3">
                      <Avatar className="w-10 h-10 border-2 border-background">
                        <AvatarImage src="" />
                        <AvatarFallback className="bg-primary text-primary-foreground text-sm">
                          GL
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="font-semibold text-sm text-foreground">Giang Bảo Luân</h4>
                          <span className="text-xs text-text-secondary">1 ngày trước</span>
                        </div>
                        <p className="text-xs text-text-secondary mb-2">hi</p>
                        <Badge variant="secondary" className="text-xs">
                          <span className="w-4 h-4 mr-1">📘</span> Facebook
                        </Badge>
                      </div>
                      <Button variant="ghost" size="icon" className="h-6 w-6">
                        <X className="h-3 w-3 text-destructive" />
                      </Button>
                    </div>
                  </div>
                  <div className="text-xs text-text-secondary bg-background-secondary p-2 rounded">
                    Gắn phiếu ghi cho Superadmin, Giang Bảo Luân, Developers2
                  </div>
                  <Button variant="ghost" size="sm" className="w-full gap-2 text-primary">
                    <Plus className="h-4 w-4" />
                    Thêm mới
                  </Button>
                </div>
              </CollapsibleContent>
            </Collapsible>

            {/* Nhân viên & Công việc */}
            <Collapsible open={staffOpen} onOpenChange={setStaffOpen} className="bg-background rounded-lg border border-border">
              <CollapsibleTrigger className="w-full p-4 flex items-center justify-between hover:bg-background-secondary transition-colors">
                <h3 className="font-semibold text-foreground">Nhân viên & Công việc</h3>
                <ChevronRight className={cn("h-4 w-4 text-text-secondary transition-transform", staffOpen && "rotate-90")} />
              </CollapsibleTrigger>
              <CollapsibleContent>
                <div className="p-4 pt-0 space-y-3">
                  <div className="text-xs text-text-secondary bg-background-secondary p-2 rounded">
                    Tối đa cho phép gán 3 nhân viên tiếp nhận
                  </div>
                  
                  <div>
                    <Label className="text-sm text-text-secondary mb-2 block">Nhân viên tiếp nhận</Label>
                    <div className="flex items-center gap-2 p-2 border border-border rounded-lg bg-background-secondary">
                      <Avatar className="w-6 h-6">
                        <AvatarFallback className="bg-primary text-primary-foreground text-xs">D2</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-foreground">Developers2</p>
                        <p className="text-xs text-text-secondary">demo1_nv1@athenafs.io</p>
                      </div>
                      <Button variant="ghost" size="icon" className="h-6 w-6">
                        <ChevronRight className="h-3 w-3" />
                      </Button>
                    </div>
                    <Button variant="ghost" size="sm" className="w-full gap-2 text-primary mt-2">
                      <Plus className="h-4 w-4" />
                      Thêm nhân viên
                    </Button>
                  </div>

                  <div className="text-xs text-text-secondary bg-background-secondary p-2 rounded">
                    Công việc được giao cho Developers2
                  </div>

                  <div>
                    <Label className="text-sm text-text-secondary mb-2 block">Công việc</Label>
                    {tasks.map((task, index) => (
                      <div key={index} className="flex items-center gap-2 mb-2">
                        <Badge variant="secondary" className="flex-1">{task}</Badge>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => setTasks(tasks.filter((_, i) => i !== index))}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                    <div className="flex gap-2">
                      <Input
                        value={newTask}
                        onChange={(e) => setNewTask(e.target.value)}
                        placeholder="Tối đa 256 ký tự"
                        className="border-border"
                        maxLength={256}
                        onKeyPress={(e) => e.key === "Enter" && handleAddTask()}
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={handleAddTask}
                        className="text-primary"
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CollapsibleContent>
            </Collapsible>

            {/* File đính kèm */}
            <Collapsible open={fileOpen} onOpenChange={setFileOpen} className="bg-background rounded-lg border border-border">
              <CollapsibleTrigger className="w-full p-4 flex items-center justify-between hover:bg-background-secondary transition-colors">
                <h3 className="font-semibold text-foreground">File đính kèm</h3>
                <ChevronRight className={cn("h-4 w-4 text-text-secondary transition-transform", fileOpen && "rotate-90")} />
              </CollapsibleTrigger>
              <CollapsibleContent>
                <div className="p-4 pt-0 space-y-3">
                  <Badge variant="secondary" className="bg-success text-success-foreground gap-2">
                    <Upload className="h-3 w-3" />
                    Dung lượng file tối đa là 50MB
                  </Badge>
                  <Button variant="outline" className="w-full gap-2">
                    <Upload className="h-4 w-4" />
                    Chọn file
                  </Button>
                </div>
              </CollapsibleContent>
            </Collapsible>

            {/* Thời gian & Nhắc nhở */}
            <Collapsible open={timeOpen} onOpenChange={setTimeOpen} className="bg-background rounded-lg border border-border">
              <CollapsibleTrigger className="w-full p-4 flex items-center justify-between hover:bg-background-secondary transition-colors">
                <h3 className="font-semibold text-foreground">Thời gian & Nhắc nhở</h3>
                <ChevronRight className={cn("h-4 w-4 text-text-secondary transition-transform", timeOpen && "rotate-90")} />
              </CollapsibleTrigger>
              <CollapsibleContent>
                <div className="p-4 pt-0 space-y-3">
                  <div>
                    <Label className="text-sm text-text-secondary mb-2 block">Ngày hết hạn</Label>
                    <div className="flex items-center gap-2 p-3 border border-border rounded-lg bg-background-secondary">
                      <Calendar className="h-4 w-4 text-text-secondary" />
                      <span className="text-sm text-foreground">11:19 26/11/2025</span>
                      <span className="text-xs text-text-secondary ml-auto">Tối thiểu 6 giờ, tối đa 30 ngày</span>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm text-text-secondary mb-2 block">
                      Nhắc nhở trước <span className="text-destructive">*</span>
                    </Label>
                    <div className="grid grid-cols-3 gap-2">
                      <Input
                        type="number"
                        defaultValue="15"
                        className="border-border col-span-2"
                      />
                      <Select defaultValue="minutes">
                        <SelectTrigger className="border-border">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="minutes">Phút</SelectItem>
                          <SelectItem value="hours">Giờ</SelectItem>
                          <SelectItem value="days">Ngày</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm text-text-secondary mb-2 block">Hình thức nhắc nhở</Label>
                    <Select defaultValue="notification">
                      <SelectTrigger className="border-border">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="notification">Thông báo</SelectItem>
                        <SelectItem value="email">Email</SelectItem>
                        <SelectItem value="sms">SMS</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CollapsibleContent>
            </Collapsible>
          </div>
        </div>
      </div>

      {/* Sticky Footer */}
      <div className="fixed bottom-0 left-0 right-0 bg-background border-t border-border p-4 shadow-lg">
        <div className="max-w-7xl mx-auto flex items-center justify-end gap-3">
          <Button
            variant="outline"
            onClick={() => navigate(-1)}
            className="px-6"
          >
            Đóng
          </Button>
          <Button
            className="bg-[#00B207] hover:bg-[#00B207]/90 text-white px-6"
            onClick={() => {
              // Handle ticket creation
              navigate(-1);
            }}
          >
            Thêm phiếu ghi
          </Button>
        </div>
      </div>

      {/* Bottom spacer */}
      <div className="h-20" />
    </div>
  );
};

export default CreateTicket;
