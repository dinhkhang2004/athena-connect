import { useState } from "react";
import { SidebarProvider } from "@/components/ui/sidebar";
import { MainSidebar } from "@/components/chat/MainSidebar";
import { ConversationList } from "@/components/chat/ConversationList";
import { ChatArea } from "@/components/chat/ChatArea";
import { CustomerInfoPanel } from "@/components/chat/CustomerInfoPanel";
import { Topbar } from "@/components/chat/Topbar";

const ChatInterface = () => {
  const [selectedConversation, setSelectedConversation] = useState<string | null>("1");
  const [showCustomerInfo, setShowCustomerInfo] = useState(false);

  return (
    <SidebarProvider>
      <div className="flex flex-col h-screen w-full bg-background">
        <Topbar />
        
        <div className="flex flex-1 overflow-hidden">
          <MainSidebar />
          
          <ConversationList 
            selectedId={selectedConversation}
            onSelect={setSelectedConversation}
          />
          
          <ChatArea 
            conversationId={selectedConversation}
            onToggleCustomerInfo={() => setShowCustomerInfo(!showCustomerInfo)}
            showCustomerInfo={showCustomerInfo}
          />

          {showCustomerInfo && (
            <div className="w-80 border-l border-border bg-background overflow-y-auto">
              <CustomerInfoPanel />
            </div>
          )}
        </div>
      </div>
    </SidebarProvider>
  );
};

export default ChatInterface;
