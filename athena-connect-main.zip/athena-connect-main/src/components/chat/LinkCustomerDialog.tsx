import { useState } from "react";
import { Search } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface LinkCustomerDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const mockCustomers = [
  { id: "1", name: "Lý Mỹ Vân", phone: "0703334948", email: "lyvan@example.com" },
  { id: "2", name: "Giang Bảo Luân", phone: "0912345678", email: "giangluan@example.com" },
  { id: "3", name: "Lê Trung Tín", phone: "0987654321", email: "letin@example.com" },
];

export function LinkCustomerDialog({ open, onOpenChange }: LinkCustomerDialogProps) {
  const [phoneQuery, setPhoneQuery] = useState("");
  
  const filteredCustomers = mockCustomers.filter(customer =>
    customer.phone.includes(phoneQuery) || customer.name.toLowerCase().includes(phoneQuery.toLowerCase())
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Liên kết khách hàng</DialogTitle>
          <DialogDescription>
            Tìm kiếm khách hàng theo số điện thoại để liên kết với cuộc hội thoại
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-text-secondary" />
            <Input
              placeholder="Nhập số điện thoại hoặc tên khách hàng"
              value={phoneQuery}
              onChange={(e) => setPhoneQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="space-y-2 max-h-96 overflow-y-auto">
            {filteredCustomers.length > 0 ? (
              filteredCustomers.map((customer) => (
                <button
                  key={customer.id}
                  className="w-full p-3 flex items-center gap-3 hover:bg-background-secondary rounded-lg transition-colors border border-border"
                  onClick={() => {
                    // Handle customer selection
                    onOpenChange(false);
                  }}
                >
                  <Avatar className="w-10 h-10">
                    <AvatarImage src="" />
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      {customer.name.split(" ").map(n => n[0]).join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 text-left">
                    <h3 className="font-semibold text-sm text-foreground">{customer.name}</h3>
                    <p className="text-xs text-text-secondary">{customer.phone}</p>
                    <p className="text-xs text-text-secondary">{customer.email}</p>
                  </div>
                  <Button size="sm" variant="outline">
                    Chọn
                  </Button>
                </button>
              ))
            ) : (
              <div className="text-center py-8 text-text-secondary">
                {phoneQuery ? "Không tìm thấy khách hàng" : "Nhập số điện thoại để tìm kiếm"}
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
