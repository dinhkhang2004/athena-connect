import { useState } from "react";
import { Search } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface AssignStaffDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const staffMembers = [
  { id: "1", name: "Developers2", email: "demo1_nv1@athenafs.io", avatar: "" },
  { id: "2", name: "CS Admin Demo", email: "csadmindemo@athenafs.io", avatar: "" },
  { id: "3", name: "CSAgent1", email: "csagent1@athenafs.io", avatar: "" },
  { id: "4", name: "Demo Head", email: "demohead@athenafs.io", avatar: "" },
];

export function AssignStaffDialog({ open, onOpenChange }: AssignStaffDialogProps) {
  const [searchQuery, setSearchQuery] = useState("");
  
  const filteredStaff = staffMembers.filter(staff =>
    staff.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    staff.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Chuyển nhân viên phụ trách</DialogTitle>
          <DialogDescription>
            Chọn nhân viên để phụ trách cuộc hội thoại này
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-text-secondary" />
            <Input
              placeholder="Tìm kiếm nhân viên theo tên hoặc email"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="space-y-2 max-h-96 overflow-y-auto">
            {filteredStaff.length > 0 ? (
              filteredStaff.map((staff) => (
                <button
                  key={staff.id}
                  className="w-full p-3 flex items-center gap-3 hover:bg-background-secondary rounded-lg transition-colors border border-border"
                  onClick={() => {
                    // Handle staff assignment
                    onOpenChange(false);
                  }}
                >
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={staff.avatar} />
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      {staff.name.split(" ").map(n => n[0]).join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 text-left">
                    <h3 className="font-semibold text-sm text-foreground">{staff.name}</h3>
                    <p className="text-xs text-text-secondary">{staff.email}</p>
                  </div>
                  <Button size="sm" variant="outline">
                    Chọn
                  </Button>
                </button>
              ))
            ) : (
              <div className="text-center py-8 text-text-secondary">
                {searchQuery ? "Không tìm thấy nhân viên" : "Nhập tên hoặc email để tìm kiếm"}
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
