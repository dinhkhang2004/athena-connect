import { useState } from "react";
import { Paperclip, Smile, Send, Ticket, Link as LinkIcon, ChevronDown, MessageSquare, PanelRightOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { CreateTicketDialog } from "./CreateTicketDialog";
import { LinkCustomerDialog } from "./LinkCustomerDialog";
import { AssignStaffDialog } from "./AssignStaffDialog";

interface ChatAreaProps {
  conversationId: string | null;
  onToggleCustomerInfo: () => void;
  showCustomerInfo: boolean;
}

const messages = [
  {
    id: "1",
    sender: "customer",
    content: "phía MSB đang gọi và làm phiền tôi quá nhiều, đừng gọi nữa",
    time: "14:29",
    status: "seen",
  },
  {
    id: "2",
    sender: "agent",
    content: "bạn cho mình xin thông tin số điện thoại để mình tiếp nhận và kiểm tra a",
    time: "14:30",
    status: "seen",
    staffName: "CS Admin Demo",
  },
  {
    id: "3",
    sender: "customer",
    content: "0703334948",
    time: "14:30",
    status: "seen",
  },
  {
    id: "4",
    sender: "customer",
    content: "đây nha bạn",
    time: "14:30",
    status: "sent",
  },
  {
    id: "5",
    sender: "agent",
    content: ".",
    time: "14:40",
    status: "seen",
    staffName: "Athena Spear",
  },
  {
    id: "6",
    sender: "customer",
    content: "kiểm tra xong báo mình nhé",
    time: "14:44",
    status: "sent",
  },
];

export function ChatArea({ conversationId, onToggleCustomerInfo, showCustomerInfo }: ChatAreaProps) {
  const [message, setMessage] = useState("");
  const [conversationStatus, setConversationStatus] = useState<"open" | "closed">("open");
  const [showCreateTicket, setShowCreateTicket] = useState(false);
  const [showLinkCustomer, setShowLinkCustomer] = useState(false);
  const [showAssignStaff, setShowAssignStaff] = useState(false);
  
  // Determine conversation properties based on conversationId
  const hasAssignedStaff = conversationId !== "3"; // Lý Mỹ Vân has no assigned staff
  const conversationType = conversationId === "3" ? "comment" : "message"; // Lý Mỹ Vân is a comment conversation

  if (!conversationId) {
    return (
      <div className="flex-1 flex items-center justify-center bg-background">
        <div className="text-center">
          <MessageSquare className="w-16 h-16 text-text-secondary mx-auto mb-4" />
          <p className="text-text-secondary">Chọn một cuộc hội thoại để bắt đầu</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-background">
      {/* Header */}
      <div className="border-b border-border p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Avatar className="w-10 h-10 border-2 border-background">
              <AvatarImage src="" />
              <AvatarFallback className="bg-primary text-primary-foreground">
                GL
              </AvatarFallback>
            </Avatar>
            <div>
              <h2 className="font-semibold text-foreground">Giang Bảo Luân</h2>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="h-8 gap-1"
                >
                  <Badge 
                    variant="secondary" 
                    className={cn(
                      "text-xs px-2",
                      conversationStatus === "open" ? "bg-success text-success-foreground" : "bg-secondary"
                    )}
                  >
                    {conversationStatus === "open" ? "Mở" : "Đóng"}
                  </Badge>
                  <ChevronDown className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => setConversationStatus("open")}>
                  Đang mở
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setConversationStatus("closed")}>
                  Đã đóng
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8"
              onClick={() => setShowCreateTicket(true)}
            >
              <Ticket className="h-4 w-4" />
            </Button>

            <Button 
              variant="ghost" 
              size="icon"
              className="h-8 w-8"
              onClick={() => setShowLinkCustomer(true)}
            >
              <LinkIcon className="h-4 w-4" />
            </Button>

            <Button 
              variant="ghost" 
              size="icon" 
              className={cn("h-8 w-8", showCustomerInfo && "bg-accent")}
              onClick={onToggleCustomerInfo}
            >
              <PanelRightOpen className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Chat Content */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {conversationType === "comment" ? (
          // Comment view
          <div className="space-y-4">
            <div className="bg-background-secondary rounded-lg p-4">
              <div className="flex items-start gap-3 mb-4">
                <Avatar className="w-10 h-10">
                  <AvatarFallback className="bg-primary text-primary-foreground">AS</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-primary">Athena Spear</h3>
                  </div>
                  <p className="text-xs text-text-secondary">14:01 18/11/2025</p>
                </div>
                <button className="text-text-secondary hover:text-foreground">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                  </svg>
                </button>
              </div>
              <p className="text-foreground mb-4">Test</p>
              <div className="border-t border-border pt-3">
                <p className="text-sm text-text-secondary mb-3">1 bình luận</p>
                <div className="flex items-start gap-3">
                  <Avatar className="w-10 h-10">
                    <AvatarImage src="" />
                    <AvatarFallback className="bg-accent text-accent-foreground">LV</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="bg-bubble-customer rounded-2xl px-4 py-2">
                      <p className="font-semibold text-sm text-primary mb-0.5">Lý Mỹ Vân</p>
                      <p className="text-xs text-text-secondary mb-1">Athena</p>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-text-secondary mt-2 ml-3">
                      <span className="text-primary font-medium cursor-pointer hover:underline">Đã thích</span>
                      <span>·</span>
                      <span className="cursor-pointer hover:text-foreground">Ẩn</span>
                      <span>·</span>
                      <span className="text-primary cursor-pointer hover:underline">Gửi tin nhắn</span>
                      <span>·</span>
                      <span>1 ngày</span>
                    </div>
                  </div>
                  <button className="text-text-secondary hover:text-foreground">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M10 6a2 2 0 110-4 2 2 0 010 4zM10 12a2 2 0 110-4 2 2 0 010 4zM10 18a2 2 0 110-4 2 2 0 010 4z"/>
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          // Message view
          <>
            <div className="flex justify-center">
              <Badge variant="secondary" className="text-xs bg-background-secondary text-text-secondary">
                Today
              </Badge>
            </div>

            {messages.map((msg) => (
              <div key={msg.id} className="space-y-2">
                <div
                  className={cn(
                    "flex gap-3",
                    msg.sender === "agent" ? "justify-end" : "justify-start"
                  )}
                >
                  {msg.sender === "customer" && (
                    <Avatar className="w-8 h-8 border-2 border-background">
                      <AvatarImage src="" />
                      <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                        GL
                      </AvatarFallback>
                    </Avatar>
                  )}

                  <div className={cn(msg.sender === "agent" && "flex flex-col items-end")}>
                    <div
                      className={cn(
                        "max-w-md px-4 py-2.5 rounded-[18px] shadow-sm",
                        msg.sender === "customer"
                          ? "bg-bubble-customer text-foreground"
                          : "bg-bubble-agent text-foreground"
                      )}
                    >
                      <p className="text-sm">{msg.content}</p>
                      <div className="flex items-center gap-1 mt-1 justify-end">
                        <span className="text-xs text-text-meta">{msg.time}</span>
                        {msg.sender === "agent" && (
                          <span className="text-xs text-text-meta">✓✓</span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </>
        )}
      </div>

      {/* Input or Action Buttons */}
      <div className="border-t border-border p-4">
        {!hasAssignedStaff ? (
          <div className="flex items-center gap-2 justify-center">
            <Button 
              variant="default" 
              className="flex-1 max-w-xs bg-primary text-primary-foreground hover:bg-primary/90"
            >
              Tham gia
            </Button>
            <Button 
              variant="outline" 
              className="flex-1 max-w-xs"
              onClick={() => setShowAssignStaff(true)}
            >
              Chuyển nhân viên
            </Button>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="h-9 w-9">
              <Paperclip className="h-4 w-4" strokeWidth={1.5} />
            </Button>
            <Input
              placeholder="Nhập tin nhắn"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="flex-1 border-border rounded-full text-sm"
            />
            <Button variant="ghost" size="icon" className="h-9 w-9">
              <Smile className="h-4 w-4" strokeWidth={1.5} />
            </Button>
            <Button
              size="icon"
              className="h-9 w-9 bg-primary hover:bg-primary/90 text-primary-foreground rounded-full"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>

      <CreateTicketDialog 
        open={showCreateTicket}
        onOpenChange={setShowCreateTicket}
      />
      
      <LinkCustomerDialog 
        open={showLinkCustomer}
        onOpenChange={setShowLinkCustomer}
      />

      <AssignStaffDialog 
        open={showAssignStaff}
        onOpenChange={setShowAssignStaff}
      />
    </div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(" ");
}
