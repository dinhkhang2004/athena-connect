import { Edit2, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";

export function CustomerInfoPanel() {
  const [showDetails, setShowDetails] = useState(true);

  return (
    <div className="flex flex-col h-full">
      {/* Header with Avatar */}
      <div className="flex flex-col items-center p-6 border-b border-border">
        <Avatar className="w-20 h-20 mb-4 border-4 border-background">
          <AvatarImage src="" />
          <AvatarFallback className="bg-primary text-primary-foreground text-2xl">
            GL
          </AvatarFallback>
        </Avatar>
        <h2 className="text-lg font-semibold text-foreground">Giang Bảo Luân</h2>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="info" className="flex-1 flex flex-col">
        <TabsList className="w-full justify-start rounded-none border-b border-border bg-transparent p-0 h-12">
          <TabsTrigger 
            value="info" 
            className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none flex-1 text-sm"
          >
            Thông tin
          </TabsTrigger>
          <TabsTrigger 
            value="contracts"
            className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none flex-1 text-sm"
          >
            Hợp đồng
          </TabsTrigger>
          <TabsTrigger 
            value="history"
            className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none flex-1 text-sm"
          >
            Lịch sử
          </TabsTrigger>
        </TabsList>

        {/* Tab Content */}
        <TabsContent value="info" className="flex-1 overflow-y-auto p-4 m-0">
          <div className="space-y-4">
            {/* Section Header */}
            <button 
              onClick={() => setShowDetails(!showDetails)}
              className="w-full flex items-center justify-between py-2 border-b border-border"
            >
              <h3 className="text-sm font-semibold text-foreground">Thông tin cá nhân</h3>
              <ChevronDown className={`h-4 w-4 text-text-secondary transition-transform ${showDetails ? 'rotate-180' : ''}`} />
            </button>

            {showDetails && (
              <div className="space-y-3">
                <div>
                  <label className="text-xs text-text-secondary">Họ và tên</label>
                  <div className="mt-1 px-3 py-2 bg-background-secondary rounded-md text-sm text-foreground">
                    Giang Bảo Luân
                  </div>
                </div>

                <div>
                  <label className="text-xs text-text-secondary">Ngày sinh</label>
                  <div className="mt-1 px-3 py-2 bg-background-secondary rounded-md text-sm text-text-secondary">
                    Chưa có dữ liệu
                  </div>
                </div>

                <div>
                  <label className="text-xs text-text-secondary">CMND/CCCD</label>
                  <div className="mt-1 px-3 py-2 bg-background-secondary rounded-md text-sm text-text-secondary">
                    Chưa có dữ liệu
                  </div>
                </div>

                <div>
                  <label className="text-xs text-text-secondary">Email</label>
                  <div className="mt-1 px-3 py-2 bg-background-secondary rounded-md text-sm text-text-secondary">
                    Chưa có dữ liệu
                  </div>
                </div>

                <div>
                  <label className="text-xs text-text-secondary">SĐT</label>
                  <div className="mt-1 px-3 py-2 bg-background-secondary rounded-md text-sm text-text-secondary">
                    Chưa có dữ liệu
                  </div>
                </div>

                <div>
                  <label className="text-xs text-text-secondary">Địa chỉ</label>
                  <div className="mt-1 px-3 py-2 bg-background-secondary rounded-md text-sm text-text-secondary">
                    Chưa có dữ liệu
                  </div>
                </div>
              </div>
            )}

            {/* Edit Button at Bottom */}
            <Button variant="ghost" size="sm" className="w-full mt-4 gap-2 text-sm">
              <Edit2 className="h-4 w-4" />
              Chỉnh sửa
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="contracts" className="flex-1 overflow-y-auto p-4 m-0">
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-foreground pb-2 border-b border-border">Hợp đồng</h3>
            <div className="text-sm text-text-secondary text-center py-8">
              Chưa có hợp đồng nào
            </div>
          </div>
        </TabsContent>

        <TabsContent value="history" className="flex-1 overflow-y-auto p-4 m-0">
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-foreground pb-2 border-b border-border">Lịch sử tương tác</h3>
            <div className="text-sm text-text-secondary text-center py-8">
              Chưa có lịch sử
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
