import { useState } from "react";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
interface ConversationListProps {
  selectedId: string | null;
  onSelect: (id: string) => void;
}
const conversations = [{
  id: "1",
  name: "Giang Bảo Luân",
  message: "kiểm tra xong báo mình nhé",
  time: "14:44",
  status: "offline",
  channel: "facebook",
  category: "message",
  unread: 0,
  conversationStatus: "Đã phản hồi",
  assignedStaff: { name: "CS Admin Demo", email: "csadmindemo@athenafs.io", avatar: "" }
}, {
  id: "2",
  name: "Lê Trung Tín",
  message: "Khi nào có thể nhận được hàng?",
  time: "11:15",
  status: "offline",
  channel: "facebook",
  category: "message",
  unread: 1,
  conversationStatus: "Mới",
  assignedStaff: { name: "Demo Head", email: "demohead@athenafs.io", avatar: "" }
}, {
  id: "3",
  name: "Lý Mỹ Vân",
  message: "Athena",
  time: "1 ngày",
  status: "offline",
  channel: "facebook",
  category: "comment",
  unread: 0,
  conversationStatus: "Chuyển Phụ Trách",
  assignedStaff: null
}, {
  id: "4",
  name: "Phạm Thị D",
  message: "Cảm ơn shop nhiều",
  time: "5 giờ trước",
  status: "offline",
  channel: "facebook",
  category: "comment",
  unread: 0,
  conversationStatus: "Đã đóng",
  assignedStaff: { name: "CS Admin Demo", email: "csadmindemo@athenafs.io", avatar: "" }
}];
export function ConversationList({
  selectedId,
  onSelect
}: ConversationListProps) {
  const [filter, setFilter] = useState<"all" | "open" | "closed">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedChannels, setSelectedChannels] = useState<string[]>(["facebook", "zalo", "zalo-oa"]);
  const toggleChannel = (channel: string) => {
    setSelectedChannels(prev => prev.includes(channel) ? prev.filter(c => c !== channel) : [...prev, channel]);
  };
  const filteredConversations = conversations.filter(conv => selectedChannels.includes(conv.channel));
  return <div className="w-80 border-r border-border bg-background flex flex-col">
      <div className="p-4 border-b border-border bg-background-secondary">
        <div className="mb-4">
          <h2 className="text-sm font-semibold text-foreground mb-1">Kênh chat</h2>
          <p className="text-xs text-text-secondary">Quản lý tất cả kênh</p>
        </div>

        <div className="flex gap-1.5 mb-4">
          <Button variant={filter === "all" ? "default" : "ghost"} size="sm" onClick={() => setFilter("all")} className={cn("text-xs flex-1 h-8 transition-all", filter === "all" ? "bg-primary text-primary-foreground shadow-sm" : "text-text-secondary hover:bg-background hover:text-foreground")}>
            Tất cả
          </Button>
          <Button variant={filter === "open" ? "default" : "ghost"} size="sm" onClick={() => setFilter("open")} className={cn("text-xs flex-1 h-8 transition-all", filter === "open" ? "bg-primary text-primary-foreground shadow-sm" : "text-text-secondary hover:bg-background hover:text-foreground")}>Tin nhắn</Button>
          <Button variant={filter === "closed" ? "default" : "ghost"} size="sm" onClick={() => setFilter("closed")} className={cn("text-xs flex-1 h-8 transition-all", filter === "closed" ? "bg-primary text-primary-foreground shadow-sm" : "text-text-secondary hover:bg-background hover:text-foreground")}>​Bình luận</Button>
        </div>

        <div className="relative mt-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-text-secondary" />
          <Input placeholder="Tìm kiếm hội thoại" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="pl-10 text-sm border-border bg-background" />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {filteredConversations.map(conversation => <button key={conversation.id} onClick={() => onSelect(conversation.id)} className={cn("w-full p-4 flex gap-3 hover:bg-background-secondary transition-colors border-b border-border", selectedId === conversation.id && "bg-primary-hover border-l-3 border-l-primary")}>
            <div className="relative">
              <Avatar className="w-12 h-12 border-2 border-background">
                <AvatarImage src="" />
                <AvatarFallback className="bg-primary text-primary-foreground text-sm">
                  {conversation.name.split(" ").map(n => n[0]).join("")}
                </AvatarFallback>
              </Avatar>
              {/* Platform badge */}
              <div className="absolute -top-1 -left-1 w-5 h-5 rounded-full bg-background flex items-center justify-center border border-border">
                {conversation.channel === "facebook" && conversation.category === "comment" && (
                  <svg className="w-3 h-3" viewBox="0 0 24 24" fill="#1877F2">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                  </svg>
                )}
                {conversation.channel === "facebook" && conversation.category === "message" && (
                  <svg className="w-3 h-3" viewBox="0 0 24 24" fill="url(#messenger-gradient)">
                    <defs>
                      <linearGradient id="messenger-gradient" x1="0%" y1="100%" x2="100%" y2="0%">
                        <stop offset="0%" style={{stopColor: '#0099FF'}} />
                        <stop offset="100%" style={{stopColor: '#A033FF'}} />
                      </linearGradient>
                    </defs>
                    <path d="M12 2C6.477 2 2 6.145 2 11.243c0 2.912 1.446 5.51 3.707 7.215V22l3.39-1.862c.905.25 1.869.385 2.903.385 5.523 0 10-4.145 10-9.243C22 6.145 17.523 2 12 2zm.993 12.464l-2.557-2.73-4.993 2.73 5.491-5.828 2.62 2.73 4.93-2.73-5.491 5.828z"/>
                  </svg>
                )}
                {conversation.channel === "zalo" && (
                  <svg className="w-3 h-3" viewBox="0 0 24 24" fill="#0068FF">
                    <path d="M12 2C6.477 2 2 6.477 2 12c0 5.523 4.477 10 10 10s10-4.477 10-10S17.523 2 12 2zm4.243 13.243L12 11l-4.243 4.243a1 1 0 01-1.414-1.414L10.586 10 6.343 5.757a1 1 0 011.414-1.414L12 8.586l4.243-4.243a1 1 0 011.414 1.414L13.414 10l4.243 4.243a1 1 0 01-1.414 1.414z"/>
                  </svg>
                )}
                {conversation.channel === "zalo-oa" && (
                  <svg className="w-3 h-3" viewBox="0 0 24 24" fill="#0068FF">
                    <circle cx="12" cy="12" r="10" />
                  </svg>
                )}
              </div>
              {conversation.unread > 0 && (
                <div className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center font-semibold shadow-sm">
                  {conversation.unread}
                </div>
              )}
            </div>

            <div className="flex-1 min-w-0 text-left">
              <div className="flex items-center justify-between mb-1">
                <h3 className="font-semibold text-sm text-foreground truncate">
                  {conversation.name}
                </h3>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-text-meta">{conversation.time}</span>
                  <Badge variant="secondary" className="text-xs flex-shrink-0">
                    {conversation.conversationStatus}
                  </Badge>
                </div>
              </div>
              <p className={cn(
                "text-xs text-text-secondary line-clamp-2",
                conversation.unread > 0 && "font-bold text-foreground"
              )}>{conversation.message}</p>
              {conversation.assignedStaff ? (
                <div className="flex items-center justify-end mt-2 gap-1">
                  <Avatar className="w-6 h-6 border-2 border-background">
                    <AvatarImage src={conversation.assignedStaff.avatar} />
                    <AvatarFallback className="bg-primary text-primary-foreground text-[10px]">
                      {conversation.assignedStaff.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                    </AvatarFallback>
                  </Avatar>
                </div>
              ) : (
                <div className="flex justify-end mt-2">
                  <span className="text-xs text-text-secondary">Chưa có người phụ trách</span>
                </div>
              )}
            </div>

          </button>)}
      </div>
    </div>;
}