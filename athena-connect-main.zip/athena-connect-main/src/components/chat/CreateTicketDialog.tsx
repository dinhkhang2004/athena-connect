import { useState } from "react";
import { ChevronDown, Flag, Calendar, Plus, X, ChevronLeft, ChevronRight, Undo, Redo, Bold, Italic, List, ListOrdered, Smile, Pen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { cn } from "@/lib/utils";
const priorities = [{
  id: "normal",
  label: "Bình thường",
  color: "bg-[#E3F2FD] text-[#0052CC]",
  icon: Flag
}, {
  id: "urgent",
  label: "Gấp",
  color: "bg-[#FF9800] text-white",
  icon: Flag
}, {
  id: "high",
  label: "Cao",
  color: "bg-[#F44336] text-white",
  icon: Flag
}, {
  id: "low",
  label: "Thấp",
  color: "bg-[#E8F5E8] text-success-foreground",
  icon: Flag
}];
interface CreateTicketDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}
export function CreateTicketDialog({
  open,
  onOpenChange
}: CreateTicketDialogProps) {
  const [priority, setPriority] = useState("normal");
  const [ticketName, setTicketName] = useState("");
  const [description, setDescription] = useState("");
  const [infoOpen, setInfoOpen] = useState(true);
  const [attachmentOpen, setAttachmentOpen] = useState(true);
  const [staffOpen, setStaffOpen] = useState(true);
  const [fileOpen, setFileOpen] = useState(true);
  const [timeOpen, setTimeOpen] = useState(true);
  const [categoryOpen, setCategoryOpen] = useState(false);
  const [tasks, setTasks] = useState<string[]>([]);
  const [newTask, setNewTask] = useState("");
  const [reminderValue, setReminderValue] = useState("15");
  const handleAddTask = () => {
    if (newTask.trim()) {
      setTasks([...tasks, newTask]);
      setNewTask("");
    }
  };
  return <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto p-0">
        <DialogHeader className="px-6 pt-6 pb-4 border-b border-border">
          <DialogTitle className="text-lg font-semibold">Tạo phiếu ghi mới</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-12 gap-6 px-6 py-4">
          {/* Left Column */}
          <div className="col-span-12 lg:col-span-7 space-y-3">
            {/* Thông tin phiếu ghi */}
            <Collapsible open={infoOpen} onOpenChange={setInfoOpen} className="bg-background rounded-lg border border-border">
              <CollapsibleTrigger className="w-full p-4 flex items-center justify-between hover:bg-background-secondary transition-colors">
                <h3 className="text-sm font-semibold text-foreground">Thông tin phiếu ghi</h3>
                <ChevronDown className={cn("h-4 w-4 text-text-secondary transition-transform", infoOpen && "rotate-180")} />
              </CollapsibleTrigger>
              <CollapsibleContent>
                <div className="px-4 pb-4 space-y-4">
                  {/* Priority Pills */}
                  <div>
                    <Label className="text-xs text-text-secondary mb-2 block">Độ ưu tiên</Label>
                    <div className="flex gap-2 flex-wrap">
                      {priorities.map(p => <button key={p.id} onClick={() => setPriority(p.id)} className={cn("px-3 py-1.5 rounded-full text-xs font-medium transition-all flex items-center gap-1.5", priority === p.id ? p.color : "bg-background-secondary text-text-secondary hover:bg-border")}>
                          <p.icon className="h-3.5 w-3.5" />
                          {p.label}
                        </button>)}
                    </div>
                  </div>

                  {/* Ticket Name */}
                  <div>
                    <Label htmlFor="ticket-name" className="text-xs text-text-secondary mb-2 block">
                      Tên phiếu ghi <span className="text-destructive">*</span>
                    </Label>
                    <Input id="ticket-name" value={ticketName} onChange={e => setTicketName(e.target.value)} placeholder="Tối đa 256 ký tự" className="rounded-lg h-9 text-sm" />
                  </div>

                  {/* Subject and Category */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label className="text-xs text-text-secondary mb-2 block">Chủ đề</Label>
                      <Select defaultValue="default">
                        <SelectTrigger className="h-9 text-sm">
                          <SelectValue placeholder="Mặc định" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="default">Mặc định</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-xs text-text-secondary mb-2 block">Phân loại</Label>
                      <Select defaultValue="none">
                        <SelectTrigger className="h-9 text-sm">
                          <SelectValue placeholder="Chọn tùy chọn" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">Chọn tùy chọn</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Description */}
                  <div>
                    <Label className="text-xs text-text-secondary mb-2 block">Mô tả</Label>
                    <div className="border border-border rounded-lg overflow-hidden">
                      {/* Toolbar */}
                      <div className="flex items-center gap-1 px-2 py-1.5 bg-background-secondary border-b border-border">
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <Undo className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <Redo className="h-3.5 w-3.5" />
                        </Button>
                        <div className="w-px h-4 bg-border mx-1" />
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <Bold className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <Italic className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <Pen className="h-3.5 w-3.5" />
                        </Button>
                        <div className="w-px h-4 bg-border mx-1" />
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <List className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <ListOrdered className="h-3.5 w-3.5" />
                        </Button>
                        <div className="w-px h-4 bg-border mx-1" />
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <Smile className="h-3.5 w-3.5" />
                        </Button>
                        <div className="ml-auto">
                          <Button variant="ghost" size="sm" className="h-7 text-xs text-primary">
                            Xem đầy đủ
                          </Button>
                        </div>
                      </div>
                      <Textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="Nhập giá trị" className="min-h-[100px] border-0 rounded-none resize-none text-sm focus-visible:ring-0" />
                    </div>
                  </div>

                  {/* Default Value */}
                  <div>
                    <Label className="text-xs text-text-secondary mb-2 block">Mặc định</Label>
                    <Input placeholder="[0-9], Tối đa 256 ký tự" className="rounded-lg h-9 text-sm" />
                  </div>
                </div>
              </CollapsibleContent>
            </Collapsible>

            {/* Phân loại */}
            <Collapsible open={categoryOpen} onOpenChange={setCategoryOpen} className="bg-background rounded-lg border border-border">
              <CollapsibleTrigger className="w-full p-4 flex items-center justify-between hover:bg-background-secondary transition-colors">
                <h3 className="text-sm font-semibold text-foreground">Phân loại</h3>
                <ChevronDown className={cn("h-4 w-4 text-text-secondary transition-transform", categoryOpen && "rotate-180")} />
              </CollapsibleTrigger>
              <CollapsibleContent>
                <div className="px-4 pb-4">
                  <div>
                    <Label className="text-xs text-text-secondary mb-2 block">Tag</Label>
                    <Input placeholder="Chưa có dữ liệu" className="rounded-lg h-9 text-sm" />
                  </div>
                </div>
              </CollapsibleContent>
            </Collapsible>
          </div>

          {/* Right Column */}
          <div className="col-span-12 lg:col-span-5 space-y-3">
            {/* Đối tượng đính kèm */}
            <Collapsible open={attachmentOpen} onOpenChange={setAttachmentOpen} className="bg-background rounded-lg border border-border">
              <CollapsibleTrigger className="w-full p-4 flex items-center justify-between hover:bg-background-secondary transition-colors">
                <h3 className="text-sm font-semibold text-foreground">Đối tượng đính kèm</h3>
                <ChevronDown className={cn("h-4 w-4 text-text-secondary transition-transform", attachmentOpen && "rotate-180")} />
              </CollapsibleTrigger>
              <CollapsibleContent>
                <div className="px-4 pb-4 space-y-3">
                  <div className="p-3 bg-background-secondary rounded-lg">
                    <div className="flex items-start gap-3">
                      <Avatar className="w-10 h-10 relative">
                        <AvatarImage src="" />
                        <AvatarFallback className="bg-primary text-primary-foreground text-xs">GL</AvatarFallback>
                        <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-[#0084FF] rounded-sm flex items-center justify-center">
                          <span className="text-white text-[8px] font-bold">f</span>
                        </div>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <div className="font-medium text-sm text-foreground">Giang Bảo Luân</div>
                          <span className="text-xs text-text-secondary">1 ngày trước</span>
                        </div>
                        <div className="text-xs text-text-secondary mb-2">hi</div>
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 bg-[#0084FF] rounded-sm flex items-center justify-center">
                            <span className="text-white text-[8px] font-bold">f</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Avatar className="w-4 h-4">
                              <AvatarFallback className="text-[8px]">A</AvatarFallback>
                            </Avatar>
                            <Avatar className="w-4 h-4">
                              <AvatarFallback className="text-[8px]">B</AvatarFallback>
                            </Avatar>
                          </div>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" className="h-6 w-6 text-destructive">
                        <X className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>

                  <div className="p-3 bg-background-secondary rounded-lg text-xs text-text-secondary">
                    Gắn phiếu ghi cho Superadmin, Giang Bảo Luân, Developers2
                  </div>

                  <Button variant="outline" size="sm" className="w-full h-8 text-xs text-primary border-dashed">
                    <Plus className="h-3.5 w-3.5 mr-1" />
                    Thêm mới
                  </Button>
                </div>
              </CollapsibleContent>
            </Collapsible>

            {/* Nhân viên & Công việc */}
            <Collapsible open={staffOpen} onOpenChange={setStaffOpen} className="bg-background rounded-lg border border-border">
              <CollapsibleTrigger className="w-full p-4 flex items-center justify-between hover:bg-background-secondary transition-colors">
                <h3 className="text-sm font-semibold text-foreground">Nhân viên & Công việc</h3>
                <ChevronDown className={cn("h-4 w-4 text-text-secondary transition-transform", staffOpen && "rotate-180")} />
              </CollapsibleTrigger>
              <CollapsibleContent>
                <div className="px-4 pb-4 space-y-3">
                  <p className="text-xs text-text-secondary bg-background-secondary p-2 rounded">Tối đa cho phép gán  1 nhân viên tiếp nhận</p>

                  <div>
                    <Label className="text-xs text-text-secondary mb-2 block">Nhân viên tiếp nhận</Label>
                    <div className="flex items-center gap-2 p-2 bg-background-secondary rounded-lg mb-2">
                      <Avatar className="w-6 h-6">
                        <AvatarFallback className="text-[10px]">D2</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-medium text-foreground">Developers2</div>
                        <div className="text-[10px] text-text-secondary truncate">demo1_nv1@athenafs.io</div>
                      </div>
                      <Button variant="ghost" size="icon" className="h-5 w-5 shrink-0">
                        <ChevronDown className="h-3 w-3" />
                      </Button>
                    </div>
                    <Button variant="outline" size="sm" className="w-full h-8 text-xs text-primary">
                      <Plus className="h-3.5 w-3.5 mr-1" />
                      Thêm nhân viên
                    </Button>
                  </div>

                  <div className="p-2 bg-background-secondary rounded text-xs text-text-secondary">
                    Công việc được giao cho Developers2
                  </div>

                  <div>
                    <Label className="text-xs text-text-secondary mb-2 block">Công việc</Label>
                    <div className="flex gap-2">
                      <Input value={newTask} onChange={e => setNewTask(e.target.value)} placeholder="Tối đa 256 ký tự" className="flex-1 h-8 text-xs" onKeyPress={e => e.key === "Enter" && handleAddTask()} />
                      <Button size="icon" onClick={handleAddTask} className="h-8 w-8 shrink-0">
                        <Plus className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                    {tasks.length > 0 && <div className="mt-2 space-y-1.5">
                        {tasks.map((task, idx) => <div key={idx} className="flex items-center gap-2 p-2 bg-background-secondary rounded">
                            <span className="flex-1 text-xs">{task}</span>
                            <Button size="icon" variant="ghost" className="h-5 w-5" onClick={() => setTasks(tasks.filter((_, i) => i !== idx))}>
                              <X className="h-3 w-3" />
                            </Button>
                          </div>)}
                      </div>}
                  </div>

                  <div className="flex items-center gap-2 pt-2">
                    <input type="text" placeholder="Tìm kiếm" className="flex-1 h-8 px-3 text-xs border border-border rounded-lg" />
                  </div>

                  <div>
                    <Label className="text-xs text-text-secondary mb-2 block">Nhân viên liên quan</Label>
                    <Button variant="outline" size="icon" className="h-8 w-8 rounded-full border-dashed">
                      <Plus className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              </CollapsibleContent>
            </Collapsible>

            {/* File đính kèm */}
            <Collapsible open={fileOpen} onOpenChange={setFileOpen} className="bg-background rounded-lg border border-border">
              <CollapsibleTrigger className="w-full p-4 flex items-center justify-between hover:bg-background-secondary transition-colors">
                <h3 className="text-sm font-semibold text-foreground">File đính kèm</h3>
                <ChevronDown className={cn("h-4 w-4 text-text-secondary transition-transform", fileOpen && "rotate-180")} />
              </CollapsibleTrigger>
              <CollapsibleContent>
                <div className="px-4 pb-4">
                  <div className="border-2 border-dashed border-[#4CAF50] rounded-lg p-3 bg-[#E8F5E8]/30">
                    <div className="flex items-center gap-2 text-[#4CAF50]">
                      <Pen className="h-4 w-4" />
                      <span className="text-xs font-medium">Dung lượng file tối đa là 50MB</span>
                    </div>
                  </div>
                </div>
              </CollapsibleContent>
            </Collapsible>

            {/* Thời gian & Nhắc nhở */}
            <Collapsible open={timeOpen} onOpenChange={setTimeOpen} className="bg-background rounded-lg border border-border">
              <CollapsibleTrigger className="w-full p-4 flex items-center justify-between hover:bg-background-secondary transition-colors">
                <h3 className="text-sm font-semibold text-foreground">Thời gian & Nhắc nhở</h3>
                <ChevronDown className={cn("h-4 w-4 text-text-secondary transition-transform", timeOpen && "rotate-180")} />
              </CollapsibleTrigger>
              <CollapsibleContent>
                <div className="px-4 pb-4 space-y-3">
                  <div>
                    <Label className="text-xs text-text-secondary mb-2 block">Ngày hết hạn</Label>
                    <div className="flex items-center gap-2 p-2 bg-background-secondary rounded-lg">
                      <span className="text-sm text-foreground flex-1">11:19 26/11/2025</span>
                      <Calendar className="h-4 w-4 text-text-secondary" />
                    </div>
                    <p className="text-[10px] text-text-secondary mt-1">Tối thiểu 6 giờ, tối đa 30 ngày</p>
                  </div>

                  <div>
                    <Label className="text-xs text-text-secondary mb-2 block">
                      Nhắc nhở trước <span className="text-destructive">*</span>
                    </Label>
                    <div className="flex items-center gap-2">
                      <div className="flex items-center border border-border rounded-lg overflow-hidden">
                        <Button variant="ghost" size="icon" className="h-8 w-8 rounded-none">
                          <ChevronLeft className="h-3.5 w-3.5" />
                        </Button>
                        <Input value={reminderValue} onChange={e => setReminderValue(e.target.value)} className="w-16 h-8 border-0 text-center text-sm focus-visible:ring-0" />
                        <Button variant="ghost" size="icon" className="h-8 w-8 rounded-none">
                          <ChevronRight className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                      <Select defaultValue="minutes">
                        <SelectTrigger className="h-8 w-24 text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="minutes">Phút</SelectItem>
                          <SelectItem value="hours">Giờ</SelectItem>
                          <SelectItem value="days">Ngày</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label className="text-xs text-text-secondary mb-2 block">Hình thức nhắc nhở</Label>
                    <Select defaultValue="notification">
                      <SelectTrigger className="h-8 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="notification">Thông báo</SelectItem>
                        <SelectItem value="email">Email</SelectItem>
                        <SelectItem value="sms">SMS</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CollapsibleContent>
            </Collapsible>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex justify-center gap-3 px-6 py-4 border-t border-border bg-background-secondary/50">
          <Button className="bg-[#00B207] hover:bg-[#00B207]/90 text-white h-9 px-6 rounded-lg text-sm font-medium" onClick={() => {
          // Handle ticket creation
          onOpenChange(false);
        }}>
            Thêm phiếu ghi
          </Button>
          <Button variant="outline" onClick={() => onOpenChange(false)} className="h-9 px-6 rounded-lg text-sm">
            Đóng
          </Button>
        </div>
      </DialogContent>
    </Dialog>;
}