import { MessageSquare, Mail, Send, BarChart3, Clock, Users, Settings, ChevronDown } from "lucide-react";
import { NavLink } from "@/components/NavLink";
import { useState } from "react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarTrigger,
  useSidebar,
  SidebarMenuSub,
  SidebarMenuSubItem,
  SidebarMenuSubButton,
} from "@/components/ui/sidebar";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Button } from "@/components/ui/button";

const mainNavItems = [
  { title: "Tổng quan", icon: BarChart3, path: "/" },
  { title: "Báo cáo", icon: BarChart3, path: "/reports" },
  { title: "Phiếu ghi", icon: Clock, path: "/tickets" },
  { title: "SLA", icon: Clock, path: "/sla" },
];

const channelItems = [
  { 
    title: "Chat", 
    icon: MessageSquare, 
    path: "/chat",
    subItems: [
      { title: "Facebook", icon: MessageSquare, path: "/chat/facebook" },
      { title: "Zalo", icon: MessageSquare, path: "/chat/zalo" },
      { title: "Zalo OA", icon: MessageSquare, path: "/chat/zalo-oa" },
    ]
  },
  { title: "Email", icon: Mail, path: "/email" },
  { title: "SMS", icon: Send, path: "/sms" },
];

const bottomItems = [
  { title: "Tổ chức", icon: Users, path: "/organization" },
  { title: "Cấu hình", icon: Settings, path: "/settings" },
];

export function MainSidebar() {
  const { open } = useSidebar();
  const [chatOpen, setChatOpen] = useState(true);

  return (
    <Sidebar className="border-r border-border" collapsible="icon">
      <SidebarHeader className="p-4 border-b border-border">
        <div className="flex items-center gap-3">
          {open && (
            <>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <span className="text-primary-foreground font-semibold text-sm">AS</span>
                </div>
                <div>
                  <h2 className="text-sm font-semibold text-foreground">Athena Spear</h2>
                  <p className="text-xs text-text-secondary">CSM</p>
                </div>
              </div>
            </>
          )}
          {!open && (
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center mx-auto">
              <span className="text-primary-foreground font-semibold text-sm">AS</span>
            </div>
          )}
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainNavItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink
                      to={item.path}
                      className="flex items-center gap-3 px-3 py-2 text-sm text-text-secondary hover:bg-background-secondary transition-colors"
                      activeClassName="bg-primary-hover text-primary border-l-3 border-l-primary font-medium"
                    >
                      <item.icon className="h-4 w-4" strokeWidth={1.5} />
                      {open && <span>{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup className="mt-6">
          {open && (
            <div className="px-3 mb-2">
              <h3 className="text-xs font-semibold text-text-secondary uppercase tracking-wider">
                Kênh tương tác
              </h3>
            </div>
          )}
          <SidebarGroupContent>
            <SidebarMenu>
              {channelItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  {item.subItems ? (
                    <Collapsible open={chatOpen} onOpenChange={setChatOpen}>
                      <CollapsibleTrigger asChild>
                        <SidebarMenuButton className="flex items-center gap-3 px-3 py-2 text-sm text-text-secondary hover:bg-background-secondary transition-colors">
                          <item.icon className="h-4 w-4" strokeWidth={1.5} />
                          {open && (
                            <>
                              <span>{item.title}</span>
                              <ChevronDown className={`ml-auto h-3.5 w-3.5 transition-transform ${chatOpen ? 'rotate-180' : ''}`} />
                            </>
                          )}
                        </SidebarMenuButton>
                      </CollapsibleTrigger>
                      {open && (
                        <CollapsibleContent>
                          <SidebarMenuSub>
                            {item.subItems.map((subItem) => (
                              <SidebarMenuSubItem key={subItem.title}>
                                <SidebarMenuSubButton asChild>
                                  <NavLink
                                    to={subItem.path}
                                    className="flex items-center gap-2 pl-9 py-1.5 text-xs text-text-secondary hover:bg-background-secondary transition-colors"
                                    activeClassName="text-primary font-medium"
                                  >
                                    <span>{subItem.title}</span>
                                  </NavLink>
                                </SidebarMenuSubButton>
                              </SidebarMenuSubItem>
                            ))}
                          </SidebarMenuSub>
                        </CollapsibleContent>
                      )}
                    </Collapsible>
                  ) : (
                    <SidebarMenuButton asChild>
                      <NavLink
                        to={item.path}
                        className="flex items-center gap-3 px-3 py-2 text-sm text-text-secondary hover:bg-background-secondary transition-colors"
                        activeClassName="bg-primary-hover text-primary border-l-3 border-l-primary font-medium"
                      >
                        <item.icon className="h-4 w-4" strokeWidth={1.5} />
                        {open && <span>{item.title}</span>}
                      </NavLink>
                    </SidebarMenuButton>
                  )}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <div className="mt-auto">
          <SidebarGroup>
            <SidebarGroupContent>
              <SidebarMenu>
                {bottomItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild>
                      <NavLink
                        to={item.path}
                        className="flex items-center gap-3 px-3 py-2 text-sm text-text-secondary hover:bg-background-secondary transition-colors"
                      >
                        <item.icon className="h-4 w-4" strokeWidth={1.5} />
                        {open && <span>{item.title}</span>}
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </div>
      </SidebarContent>
    </Sidebar>
  );
}
